#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include <pthread.h>
#include <arpa/inet.h>
#include "sbuf.h"
#include "sbuf.c"

// Will Hainsworth - hainsw

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

#define BUF_SIZE 500

static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:97.0) Gecko/20100101 Firefox/97.0";

int all_headers_received(char *);
int parse_request(char *, char *, char *, char *, char *, char *);
int open_sfd(char **);
void *handle_clients(void *vargp);
void handle_client(int cfd);
void test_parser();
void print_bytes(unsigned char *, int);

sbuf_t sbuf;

int main(int argc, char *argv[]) {
	struct sockaddr_storage peer_addr;
	socklen_t peer_addr_len = sizeof(struct sockaddr_storage);
	int sfd, cfd;

	pthread_t tid;

	sbuf_init(&sbuf, 5);
	for (int i = 0; i < 8; i++)
		pthread_create(&tid, NULL, handle_clients, NULL);  

  	sfd = open_sfd(argv);
	
	while(1) {
		memset (&peer_addr, 0, sizeof(peer_addr));
		if ((cfd = accept(sfd, (struct sockaddr*)&peer_addr, &peer_addr_len)) == -1) {
			printf("accept error\n");
			exit(EXIT_FAILURE);
		}

		sbuf_insert(&sbuf, cfd);
	}

	return 0;
}


int all_headers_received(char *request) {
	if (strstr(request, "\r\n\r\n") != NULL) {
		return 1;
	}
	return 0;
}

int parse_request(char *request, char *method, char *hostname, char *port, char *path, char *headers) {
  	if (all_headers_received(request)) {

		memset(method, 0, 16);
		strncpy(method, request, (size_t)(((char*)strchr(request, ' ')) - request));

		char *hostStrBegins = strstr(request, "Host: ") + 6;
		char *hostStrEnds;
		size_t lenHost;
		char *portColon = strchr(hostStrBegins, ':');

		memset(port, 0, 8);
		if (((char*)strstr(hostStrBegins, "\r\n") > portColon) && (portColon != NULL)) {
			size_t lenPort = (char*)strchr(hostStrBegins, '\n') - portColon;
			strncpy(port, portColon + 1, lenPort - 2);
			port[strcspn(port, "\r\n")] = 0;
			hostStrEnds = portColon;
		}
		else {
			strcpy(port, "80");
			hostStrEnds = strchr(hostStrBegins, '\n');
		}

		lenHost = hostStrEnds - hostStrBegins;
		memset(hostname, 0, 64);
		strncpy(hostname, hostStrBegins, lenHost);
		hostname[strcspn(hostname, "\r\n")] = 0;

		char *startPath = strchr(strstr(request, "http")+10, '/');
		memset(path, 0, 64);
		strncpy(path, startPath, (size_t)((char*)strchr(startPath, ' ') - startPath));

		memset(headers, 0, 1024);
		strcpy(headers, (char*)(strchr(request, '\n') + 1));

		return 1;
	}

  	return 0;
}

int open_sfd (char *argv[]) {
	int sfd;
	struct sockaddr_in addr;

	addr.sin_family = AF_INET;
	addr.sin_port = htons(atoi(argv[1]));
	addr.sin_addr.s_addr = 0;

	if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("socket error\n");
		exit(EXIT_FAILURE);
	}

	int optval = 1;
	if (setsockopt(sfd, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval)) == -1) {
		perror("setsockopt error\n");
		exit(EXIT_FAILURE);
	}

	if (bind(sfd, (struct sockaddr*)&addr, sizeof(struct sockaddr_in)) == -1) {
		close(sfd);
		perror("bind error\n");
		exit(EXIT_FAILURE);
	}

	if (listen(sfd, MAX_OBJECT_SIZE) == -1) {
		close(sfd);
		perror("listen error\n");
		exit(EXIT_FAILURE);
	}	

	return sfd;
}

void *handle_clients(void *vargp) {  
	pthread_detach(pthread_self()); 
	while (1) { 
		int cfd = sbuf_remove(&sbuf);
		handle_client(cfd);
		close(cfd);
	}
}

void handle_client(int cfd) {
	int nbuf = 0;
	int r = 0;

	char method[16], hostname[64], port[8], path[64], headers[1024];

	char returnBuf[MAX_OBJECT_SIZE];
	char requestBuf[MAX_OBJECT_SIZE];

	memset(requestBuf, 0, MAX_OBJECT_SIZE);
	memset(returnBuf, 0, MAX_OBJECT_SIZE);

	while (!all_headers_received(returnBuf)) {
		r = read(cfd, returnBuf + nbuf, MAX_OBJECT_SIZE);
		nbuf += r;
	}

	if (parse_request(returnBuf, method, hostname, port, path, headers)) {

		char space[2] = " ";
		char http[12] = " HTTP/1.0\r\n";
		char connHeader[20] = "Connection: close\r\n";
		char endln[3] = "\r\n";
		char hostLabel[7] = "Host: ";
		char pConnHeader[28] = "Proxy-Connection: close\r\n\r\n";
		char colon[2] = ":";
		strcat(requestBuf, method);
		strcat(requestBuf, space);
		strcat(requestBuf, path);
		strcat(requestBuf, http);
		strcat(requestBuf, hostLabel);
		strcat(requestBuf, hostname);
		if (strcmp(port, "80") != 0) {
			strcat(requestBuf, colon);
			strcat(requestBuf, port);
		}
		strcat(requestBuf, endln);
		strcat(requestBuf, user_agent_hdr);
		strcat(requestBuf, endln);
		strcat(requestBuf, connHeader);
		strcat(requestBuf, pConnHeader);
		

		struct addrinfo hints;
		struct addrinfo *result, *rp;
		int fd, s;

		memset(&hints, 0, sizeof(struct addrinfo));

		hints.ai_family = AF_UNSPEC;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_flags = 0;
		hints.ai_protocol = 0;

		s = getaddrinfo(hostname, port, &hints, &result);
		if (s != 0) {
			fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
			exit(EXIT_FAILURE);
		}

		for (rp = result; rp != NULL; rp = rp->ai_next) {
			fd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
			if (fd == -1)
				continue;
			if (connect(fd, rp->ai_addr, rp->ai_addrlen) != -1)
				break;
			close(fd);
		}
		if (rp == NULL) {
			fprintf(stderr, "Could not connect\n");
		}

		freeaddrinfo(result);


		if (write(fd, requestBuf, MAX_OBJECT_SIZE) == -1) {
			printf("Error with write\n");
			exit(EXIT_FAILURE);
		}

		memset(returnBuf, 0, MAX_OBJECT_SIZE);
		nbuf = 0;
		r = 1;
		while(r != 0) {
			r = read(fd, returnBuf + nbuf, MAX_OBJECT_SIZE);
			nbuf += r;
		}

		printf("[%s]/n", returnBuf);

		if (write(cfd, returnBuf, nbuf + 1) == -1) {
			printf("Error with write\n");
			exit(EXIT_FAILURE);
		}

	} else {
		printf("REQUEST INCOMPLETE\n");
	}
}

void test_parser() {
	int i;
	char method[16], hostname[64], port[8], path[64], headers[1024];

    char *reqs[] = {
		"GET http://www.example.com/index.html HTTP/1.0\r\n"
		"Host: www.example.com\r\n"
		"User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0\r\n"
		"Accept-Language: en-US,en;q=0.5\r\n\r\n",

		"GET http://www.example.com:8080/index.html?foo=1&bar=2 HTTP/1.0\r\n"
		"Host: www.example.com:8080\r\n"
		"User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0\r\n"
		"Accept-Language: en-US,en;q=0.5\r\n\r\n",

		"GET http://www.example.com:8080/index.html HTTP/1.0\r\n",

		NULL
	};

	for (i = 0; reqs[i] != NULL; i++) {
		printf("Testing %s\n", reqs[i]);
		if (parse_request(reqs[i], method, hostname, port, path, headers)) {
			printf("METHOD: %s\n", method);
			printf("HOSTNAME: %s\n", hostname);
			printf("PORT: %s\n", port);
			printf("PATH: %s\n", path);
			printf("HEADERS: %s\n", headers);
		} else {
			printf("REQUEST INCOMPLETE\n");
		}
	}
}

void print_bytes(unsigned char *bytes, int byteslen) {
	int i, j, byteslen_adjusted;

	if (byteslen % 8) {
		byteslen_adjusted = ((byteslen / 8) + 1) * 8;
	} else {
		byteslen_adjusted = byteslen;
	}
	for (i = 0; i < byteslen_adjusted + 1; i++) {
		if (!(i % 8)) {
			if (i > 0) {
				for (j = i - 8; j < i; j++) {
					if (j >= byteslen_adjusted) {
						printf("  ");
					} else if (j >= byteslen) {
						printf("  ");
					} else if (bytes[j] >= '!' && bytes[j] <= '~') {
						printf(" %c", bytes[j]);
					} else {
						printf(" .");
					}
				}
			}
			if (i < byteslen_adjusted) {
				printf("\n%02X: ", i);
			}
		} else if (!(i % 4)) {
			printf(" ");
		}
		if (i >= byteslen_adjusted) {
			continue;
		} else if (i >= byteslen) {
			printf("   ");
		} else {
			printf("%02X ", bytes[i]);
		}
	}
	printf("\n");
}
